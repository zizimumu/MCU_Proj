/*
 * Webserver_tasks.c
 * Brief: Starts Ethernet, GMAC and TCP tasks
 *
 * Copyright (C) 2016 - 2017 Atmel Corporation. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 *
 * 3. The name of Atmel may not be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * 4. This software may only be redistributed and used in connection with an
 *    Atmel microcontroller product.
 *
 * THIS SOFTWARE IS PROVIDED BY ATMEL "AS IS" AND ANY EXPRESS OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT ARE
 * EXPRESSLY AND SPECIFICALLY DISCLAIMED. IN NO EVENT SHALL ATMEL BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 * ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *
 */ 
 

#include "atmel_start.h"
#include "Webserver_tasks.h"


/* The function that implements the net connection. */
portTASK_FUNCTION_PROTO( process_connection, pvParameters );

/* The function that initiates webserver process */
void vBasicWEBServer(void *p);

/*! Current nb of HTTP connections. */
static portSHORT sCurrentNbHTTPConn = 0;

/* Status of light and temperature */
portCHAR light_stat[12], temp_stat[12];

/* Function to add header to the response */
static unsigned portLONG prulweb_BuildHeaders(portCHAR * response, int s, char * title, char* extra_header, char* me, char* mt );

/*! Mutex to access the current_nb_http_conn variable. */
static SemaphoreHandle_t xMutexNbHTTPConn;

/*! The datalog system mutex. */
extern xSemaphoreHandle     xLOGMutex;

/*! The handlers for connection tasks. */
xTaskHandle tTaskHandle[webHTTP_NB_CONN] = { NULL };

/* Handle to the Ethernet task */
static TaskHandle_t  xCreatedEthernetTask;

/*! The LOG system mutex. */
xSemaphoreHandle     xLOGMutex;

gmac_device gs_gmac_dev;
static bool           link_up   = false;
volatile static bool  recv_flag = false;


void mac_receive_cb(struct mac_async_descriptor *desc)
{
	recv_flag = true;
}

/**
 * \brief Callback for GMAC interrupt.
 * Give semaphore for which gmac_task waits
 */
void gmac_handler_cb(void)
{
	portBASE_TYPE xGMACTaskWoken = pdFALSE;
	xSemaphoreGiveFromISR(gs_gmac_dev.rx_sem, &xGMACTaskWoken);
	portEND_SWITCHING_ISR(xGMACTaskWoken);
}

static void print_ipaddress(void)
{
	static char tmp_buff[16];
	printf("IP_ADDR    : %s\r\n", ipaddr_ntoa_r((const ip_addr_t *)&(TCPIP_STACK_INTERFACE_0_desc.ip_addr), tmp_buff, 16));
	printf("NET_MASK   : %s\r\n", ipaddr_ntoa_r((const ip_addr_t *)&(TCPIP_STACK_INTERFACE_0_desc.netmask), tmp_buff, 16));
	printf("GATEWAY_IP : %s\r\n", ipaddr_ntoa_r((const ip_addr_t *)&(TCPIP_STACK_INTERFACE_0_desc.gw), tmp_buff, 16));
}

extern err_t dhcp_start(struct netif *netif);
static void tcpip_init_done(void *arg)
{
	sys_sem_t *sem;
	sem = (sys_sem_t *)arg;
	u8_t mac[6] = {0x00,0x00,0x00,0x00,0x20,0x76};
	mac_async_register_callback(&COMMUNICATION_IO, MAC_ASYNC_RECEIVE_CB, gmac_handler_cb);
	hri_gmac_set_IMR_RCOMP_bit(COMMUNICATION_IO.dev.hw);

	printf("tcpip_init_done\r\n");
	while ((ethernet_phy_get_link_status(&ETHERNET_PHY_0_desc, &link_up)) != ERR_NONE && !(link_up))
	{
		os_sleep(20);
	}
	
	printf("link up\r\n");

	/* Enable NVIC GMAC interrupt. */
	/* Interrupt priorities. (lowest value = highest priority) */
	/* ISRs using FreeRTOS *FromISR APIs must have priorities below or equal to */
	/* configLIBRARY_MAX_SYSCALL_INTERRUPT_PRIORITY. */
	NVIC_SetPriority(GMAC_IRQn,5);
	NVIC_EnableIRQ(GMAC_IRQn);
	mac_async_enable(&COMMUNICATION_IO);

	TCPIP_STACK_INTERFACE_0_init(mac);

	TCPIP_STACK_INTERFACE_0_desc.input = tcpip_input;

	gs_gmac_dev.netif = &TCPIP_STACK_INTERFACE_0_desc;

	sys_thread_t id;

	/* Incoming packet notification semaphore. */
	gs_gmac_dev.rx_sem = xSemaphoreCreateCounting( CONF_GMAC_RXDESCR_NUM,0 );

	if( gs_gmac_dev.rx_sem == NULL )
	{
		//return ERR_MEM;
	}

	id = sys_thread_new("GMAC", gmac_task, &gs_gmac_dev,
	netifINTERFACE_TASK_STACK_SIZE, netifINTERFACE_TASK_PRIORITY);
	LWIP_ASSERT("ethernetif_init: GMAC Task allocation ERROR!\n",
	(id != 0));

	netif_set_default(&TCPIP_STACK_INTERFACE_0_desc);

	#if CONF_TCPIP_STACK_INTERFACE_0_DHCP
	/* DHCP mode. */
	if (ERR_OK != dhcp_start(&TCPIP_STACK_INTERFACE_0_desc)) {
		LWIP_ASSERT("ERR_OK != dhcp_start", 0);
	}

	#else
	netif_set_up(&TCPIP_STACK_INTERFACE_0_desc);

	#endif
	print_ipaddress();
	
	sys_sem_signal (sem); /* Signal the waiting thread that the TCP/IP init is done. */
}


/**
 * \brief Task for ethernet
 * Start TCP/IP thread and create tasks for various TCP process
 */
static void task_ethernet(void *p)
{
	sys_sem_t sem;

	printf("task_ethernet\r\n");
	
	sys_sem_new(&sem, 0); /* Create a new semaphore. */
	tcpip_init(tcpip_init_done, &sem);
	sys_sem_wait(&sem);     /* Block until the lwIP stack is initialized. */
	sys_sem_free(&sem);     /* Free the semaphore. */

	// Create the LOG mutex.
	vSemaphoreCreateBinary( xLOGMutex );
	if( NULL == xLOGMutex )
	{
		while( 1 ); // The mutex creation failed.
	}
	
 	sys_thread_new("WEB", vBasicWEBServer, (void *)NULL,
 	lwipBASIC_WEB_SERVER_STACK_SIZE,
 	lwipBASIC_WEB_SERVER_PRIORITY);
	
	/* Kill this task. */
	vTaskDelete(NULL);
}

/*! \brief WEB server main task
 *         check for incoming connection and process it
 *
 */
portTASK_FUNCTION( vBasicWEBServer, pvParameters )
{
  struct netconn  *pxHTTPListener, *pxNewConnection;
  portSHORT       TaskIdx;
  portLONG        err_count;
 
   /* initialize current nb connection */
  sCurrentNbHTTPConn = 0;

  vSemaphoreCreateBinary( xMutexNbHTTPConn );

  // Create a new tcp connection handle
  pxHTTPListener = netconn_new( NETCONN_TCP );
  netconn_bind(pxHTTPListener, NULL, webHttpPort );
  netconn_listen( pxHTTPListener );
  // Loop forever
  for( ;; )
  {
#if ( (LWIP_VERSION) == ((1U << 24) | (3U << 16) | (2U << 8) | (LWIP_VERSION_RC)) )
    /* Wait for a first connection. */
    pxNewConnection = netconn_accept(pxHTTPListener);
#else
    while(netconn_accept(pxHTTPListener, &pxNewConnection) != ERR_OK)
    {
		vTaskDelay( webSHORT_DELAY );
	}
#endif
    if(pxNewConnection != NULL)
    {
      /* read the nb of connection, no need to use Mutex */
      while( webHTTP_NB_CONN == sCurrentNbHTTPConn )
      {
        vTaskDelay( webSHORT_DELAY );
      }

      // Find an available spot in the tTaskHandle[] array.
      // We're sure to find one because sCurrentNbHTTPConn < webHTTP_NB_CONN.
      TaskIdx = 0;
      while( NULL != tTaskHandle[TaskIdx] ) TaskIdx++;

      while( xSemaphoreTake(xMutexNbHTTPConn , portMAX_DELAY ) != pdTRUE );
      sCurrentNbHTTPConn++;
      // Release the mutex.
      xSemaphoreGive( xMutexNbHTTPConn );

      if( xTaskCreate( process_connection,
                                ( const portCHAR * )"WCONN",
                                webHTTP_CONNECTION_STACK_SIZE, pxNewConnection,
                                webHTTP_CONNECTION_PRIORITY,
                                &tTaskHandle[TaskIdx] ) != pdPASS)
      {
          /* delete connection */
          err_count = 4;
          while( netconn_close( pxNewConnection ) != ERR_OK )
          {
            if (--err_count == 0) break;
            vTaskDelay( webSHORT_DELAY );
          }
          err_count = 4;
          while( netconn_delete( pxNewConnection ) != ERR_OK )
          {
            if (--err_count == 0) break;
            vTaskDelay( webSHORT_DELAY );
          }

          while( xSemaphoreTake(xMutexNbHTTPConn , portMAX_DELAY ) != pdTRUE );
          sCurrentNbHTTPConn--;
		  
          // Release the mutex.
          xSemaphoreGive( xMutexNbHTTPConn );
      }// end if task not created
    }// end if new connection

  }// end infinite loop
}

/*! \brief Processes an incoming connection.
 *         
 */
portTASK_FUNCTION( process_connection, pvParameters )
{
	struct netconn *current_conn;
	portLONG err_count;
	portSHORT i;
	struct netbuf *inbuf;
	unsigned portSHORT len;
	portCHAR *rq;
	err_t    err_recv;
	
	current_conn = ( struct netconn *)pvParameters;
	err_recv = netconn_recv( current_conn, &inbuf);
	if (err_recv != ERR_OK)
	{
		if (inbuf != NULL)
		goto delete_buffer;
	}
	
	if( inbuf != NULL )
	{
		/* Get the pointer to the data in the first netbuf
		fragment which we hope contains the request. */
		netbuf_data(inbuf,( void * ) &rq, &len);
		/* Parse the first line of the request. */
		if ( rq == (char*) 0 )
		{
			goto delete_buffer;
		}
		
		/* Check if the request was an HTTP "GET /\r\n". */
		if(( NULL != rq               )
		&& ( !strncmp( rq, "GET", 3 ) ))
		{
			//process_get_req
		}
	}
	delete_buffer:
	netbuf_delete(inbuf);
	
// Since we cannot know when the client has closed the connection(lwIP bug),
// we set a 1000ms delay (the time for the file transfer to end), then we close
// the connection ourselves.
// NOTE FOR IMPROVMENTS: we could set this delay depending on the amount of
// data that was sent to the client(the more the longer).
vTaskDelay( 50 );
err_count = 4;
while( netconn_close( current_conn ) != ERR_OK )
{
	if (--err_count == 0) break;
	vTaskDelay( webSHORT_DELAY );
}

err_count = 4;
while( netconn_delete( current_conn ) != ERR_OK )
{
	if (--err_count == 0) break;
	vTaskDelay( webSHORT_DELAY );
}


while( xSemaphoreTake(xMutexNbHTTPConn , portMAX_DELAY ) != pdTRUE );
for (i = 0 ; i < webHTTP_NB_CONN ; i++)
{
	if (tTaskHandle[i] == xTaskGetCurrentTaskHandle())
	{
		tTaskHandle[i] = NULL;
		break;
	}
}
sCurrentNbHTTPConn--;

// Release the mutex.
xSemaphoreGive( xMutexNbHTTPConn );

vTaskDelete(NULL);
/* nothing after delete task : this will not be reached */

}


/**
 * \brief Task for GMAC. 
 * Waits for GMAC interrupt and begins processing of received packets
 */
void gmac_task(void *pvParameters)
{
	gmac_device *ps_gmac_dev = pvParameters;

	while (1) {
		/* Wait for the counting RX notification semaphore. */
		xSemaphoreTake( ps_gmac_dev->rx_sem, portMAX_DELAY);
		
		/* Process the incoming packet. */
		ethernetif_mac_input(ps_gmac_dev->netif);
	}
}

/**
 * \brief Create OS task for ethernet
 */
void task_ethernet_create(void)
{
		
	/* Create task for Ethernet */ //configMAX_PRIORITIES -1
	if (xTaskCreate(task_ethernet, "Ethernet", TASK_ETHERNET_STACK_SIZE, NULL, configMAX_PRIORITIES -1 , &xCreatedEthernetTask) != pdPASS) {
		printf("task_ethernet_create err\r\n");
		while (1) {
			;
		}
	}
}
