/*
 * Webserver_tasks.c
 * Brief: Starts Ethernet, GMAC and TCP tasks
 *
 * Copyright (C) 2016 - 2017 Atmel Corporation. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 *
 * 3. The name of Atmel may not be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * 4. This software may only be redistributed and used in connection with an
 *    Atmel microcontroller product.
 *
 * THIS SOFTWARE IS PROVIDED BY ATMEL "AS IS" AND ANY EXPRESS OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT ARE
 * EXPRESSLY AND SPECIFICALLY DISCLAIMED. IN NO EVENT SHALL ATMEL BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 * ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *
 */ 
 

#include <asf.h>
#include <string.h>
#include "ethernet.h"
#include "lwip/dhcp.h"
#include "Webserver_tasks.h"
#include "lwip/init.h"
#include "network/dhcpserver/dhcpserver.h"

#define TASK_ETHERNET_STACK_SIZE (512)
#define lwipBASIC_WEB_SERVER_STACK_SIZE   (512*2)
#define lwipBASIC_WEB_SERVER_PRIORITY     (tskIDLE_PRIORITY + 2)
//#define netifINTERFACE_TASK_STACK_SIZE    512
//#define netifINTERFACE_TASK_PRIORITY      (tskIDLE_PRIORITY + 5)


/*! Mutex to access the current_nb_http_conn variable. */
static SemaphoreHandle_t xMutexNbHTTPConn;

/*! The handlers for connection tasks. */
xTaskHandle tTaskHandle[webHTTP_NB_CONN] = { NULL };
char g_c_ipconfig[32];
/* Handle to the Ethernet task */
static TaskHandle_t  xCreatedEthernetTask;
static portSHORT sCurrentNbHTTPConn = 0;

void vBasicWEBServer(void *p);
portTASK_FUNCTION_PROTO( process_connection, pvParameters );

#define TASK_DHCPS_STACK_SIZE              (0x1000/sizeof(portSTACK_TYPE))
#define TASK_DHCPS_STACK_PRIORITY          (tskIDLE_PRIORITY+5)
TaskHandle_t	task_dhcp_server_handle;

extern struct netif gs_net_if;

void task_dhcp_server(void* param){

	//struct netconn *newconn;
	u32_t addr;

	addr = client_address.addr;
	dhcps_start(netif_get_default(),netif_get_default()->ip_addr);
	
	/* Program main loop. */
	while (1)
	{
		vTaskDelay(500);
		
		if (addr != client_address.addr)
		{
			addr = client_address.addr;
			printf("new client connected\r\n");
			printf("client_address:%x\r\n",client_address.addr);
			
			memset(g_c_ipconfig,0,sizeof(g_c_ipconfig));
			strcat((char*)g_c_ipconfig, inet_ntoa(*(struct in_addr *)&client_address.addr));
			printf("current IP addr %s\r\n",g_c_ipconfig);
		}
		
	}
}


/**
 * \brief Task for ethernet
 * Start TCP/IP thread and create tasks for various TCP process
 */

static void task_ethernet(void *p)
{
	
	//sys_sem_t sem;

	printf("task_ethernet working\r\n");
	
	init_ethernet();
	
#ifdef DHCP_USED	
	//wait DHCP get IP from host
	while(gs_net_if.dhcp->state != DHCP_BOUND){
		vTaskDelay(100);
	}
	printf("get IP from host\r\n");
#endif

	if (netif_is_up(&gs_net_if)) {
		strcat((char*)g_c_ipconfig, inet_ntoa(*(struct in_addr *)&(gs_net_if.ip_addr)));
		printf("current IP addr %s\r\n",g_c_ipconfig);
	}
	
 	sys_thread_new("WEB", vBasicWEBServer, (void *)NULL,
 	lwipBASIC_WEB_SERVER_STACK_SIZE,
 	lwipBASIC_WEB_SERVER_PRIORITY);

	if(xTaskCreate(task_dhcp_server, "dhcp_server", TASK_DHCPS_STACK_SIZE, NULL,
		TASK_DHCPS_STACK_PRIORITY, &task_dhcp_server_handle) != pdPASS){
		printf("Failed to create test httpd task\r\n");
	}
		
	/* Kill this task. */
	vTaskDelete(NULL);
}

/*! \brief WEB server main task
 *         check for incoming connection and process it
 *
 */
portTASK_FUNCTION( vBasicWEBServer, pvParameters )
{
  struct netconn  *pxHTTPListener, *pxNewConnection;
  portSHORT       TaskIdx;
  portLONG        err_count;
 
 printf("vBasicWEBServer\r\n");
   /* initialize current nb connection */
  sCurrentNbHTTPConn = 0;

  vSemaphoreCreateBinary( xMutexNbHTTPConn );

  // Create a new tcp connection handle
  pxHTTPListener = netconn_new( NETCONN_TCP );
  netconn_bind(pxHTTPListener, NULL, webHttpPort );
  netconn_listen( pxHTTPListener );
  // Loop forever
  for( ;; )
  {
#if ( (LWIP_VERSION) == ((1U << 24) | (3U << 16) | (2U << 8) | (LWIP_VERSION_RC)) )
    /* Wait for a first connection. */
    pxNewConnection = netconn_accept(pxHTTPListener);
#else
    while(netconn_accept(pxHTTPListener, &pxNewConnection) != ERR_OK)
    {
		vTaskDelay( webSHORT_DELAY );
	}
#endif

	printf("netconn_accept\r\n");
	
    if(pxNewConnection != NULL)
    {
      /* read the nb of connection, no need to use Mutex */
      while( webHTTP_NB_CONN == sCurrentNbHTTPConn )
      {
        vTaskDelay( webSHORT_DELAY );
      }

      // Find an available spot in the tTaskHandle[] array.
      // We're sure to find one because sCurrentNbHTTPConn < webHTTP_NB_CONN.
      TaskIdx = 0;
      while( NULL != tTaskHandle[TaskIdx] ) TaskIdx++;

      while( xSemaphoreTake(xMutexNbHTTPConn , portMAX_DELAY ) != pdTRUE );
      sCurrentNbHTTPConn++;
      // Release the mutex.
      xSemaphoreGive( xMutexNbHTTPConn );

      if( xTaskCreate( process_connection,
                                ( const portCHAR * )"WCONN",
                                webHTTP_CONNECTION_STACK_SIZE, pxNewConnection,
                                webHTTP_CONNECTION_PRIORITY,
                                &tTaskHandle[TaskIdx] ) != pdPASS)
      {
          /* delete connection */
          err_count = 4;
          while( netconn_close( pxNewConnection ) != ERR_OK )
          {
            if (--err_count == 0) break;
            vTaskDelay( webSHORT_DELAY );
          }
          err_count = 4;
          while( netconn_delete( pxNewConnection ) != ERR_OK )
          {
            if (--err_count == 0) break;
            vTaskDelay( webSHORT_DELAY );
          }

          while( xSemaphoreTake(xMutexNbHTTPConn , portMAX_DELAY ) != pdTRUE );
          sCurrentNbHTTPConn--;
		  
          // Release the mutex.
          xSemaphoreGive( xMutexNbHTTPConn );
      }// end if task not created
    }// end if new connection

  }// end infinite loop
}

/*! \brief Processes an incoming connection.
 *         
 */
portTASK_FUNCTION( process_connection, pvParameters )
{
	struct netconn *current_conn;
	portLONG err_count;
	portSHORT i;
	struct netbuf *inbuf;
	unsigned portSHORT len;
	portCHAR *rq;
	err_t    err_recv;
	
	current_conn = ( struct netconn *)pvParameters;
	err_recv = netconn_recv( current_conn, &inbuf);
	if (err_recv != ERR_OK)
	{
		if (inbuf != NULL)
		goto delete_buffer;
	}
	
	if( inbuf != NULL )
	{
		/* Get the pointer to the data in the first netbuf
		fragment which we hope contains the request. */
		netbuf_data(inbuf,( void * ) &rq, &len);
		/* Parse the first line of the request. */
		if ( rq == (char*) 0 )
		{
			goto delete_buffer;
		}

		if( NULL != rq               )
		{
			printf("receive %s\r\n",rq);
		}
		
	}
delete_buffer:
	netbuf_delete(inbuf);
	
	// Since we cannot know when the client has closed the connection(lwIP bug),
	// we set a 1000ms delay (the time for the file transfer to end), then we close
	// the connection ourselves.
	// NOTE FOR IMPROVMENTS: we could set this delay depending on the amount of
	// data that was sent to the client(the more the longer).
	vTaskDelay( 50 );
	err_count = 4;
	while( netconn_close( current_conn ) != ERR_OK )
	{
		if (--err_count == 0) break;
		vTaskDelay( webSHORT_DELAY );
	}

	err_count = 4;
	while( netconn_delete( current_conn ) != ERR_OK )
	{
		if (--err_count == 0) break;
		vTaskDelay( webSHORT_DELAY );
	}


	while( xSemaphoreTake(xMutexNbHTTPConn , portMAX_DELAY ) != pdTRUE );
	for (i = 0 ; i < webHTTP_NB_CONN ; i++)
	{
		if (tTaskHandle[i] == xTaskGetCurrentTaskHandle())
		{
			tTaskHandle[i] = NULL;
			break;
		}
	}
	sCurrentNbHTTPConn--;

	// Release the mutex.
	xSemaphoreGive( xMutexNbHTTPConn );

	vTaskDelete(NULL);
	/* nothing after delete task : this will not be reached */

}


/**
 * \brief Create OS task for ethernet
 */
void task_ethernet_create(void)
{
		
	/* Create task for Ethernet */ //configMAX_PRIORITIES -1
	if (xTaskCreate(task_ethernet, "Ethernet", TASK_ETHERNET_STACK_SIZE, NULL, configMAX_PRIORITIES -1 , &xCreatedEthernetTask) != pdPASS) {
		printf("task_ethernet_create err\r\n");
		while (1) {
			;
		}
	}
}
