/**
 * \file
 *
 * \brief CAN FD Example.
 *
 * Copyright (c) 2019 Microchip Technology Inc. and its subsidiaries.
 *
 * \asf_license_start
 *
 * \page License
 *
 * Subject to your compliance with these terms, you may use Microchip
 * software and any derivatives exclusively with Microchip products.
 * It is your responsibility to comply with third party license terms applicable
 * to your use of third party software (including open source software) that
 * may accompany Microchip software.
 *
 * THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS".  NO WARRANTIES,
 * WHETHER EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE,
 * INCLUDING ANY IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY,
 * AND FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT WILL MICROCHIP BE
 * LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, INCIDENTAL OR CONSEQUENTIAL
 * LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND WHATSOEVER RELATED TO THE
 * SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS BEEN ADVISED OF THE
 * POSSIBILITY OR THE DAMAGES ARE FORESEEABLE.  TO THE FULLEST EXTENT
 * ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN ANY WAY
 * RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT OF FEES, IF ANY,
 * THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.
 *
 * \asf_license_stop
 *
 */

#include <atmel_start.h>
#include <hpl_can_config.h>
/**
 * \brief display configuration menu.
 */
static void display_menu(void)
{
	printf("Menu :\r\n"
	       "  -- Select the action:\r\n"
	       "  0: Set standard filter ID 0: 0x45A, store into Rx buffer. \r\n"
	       "  1: Set standard filter ID 1: 0x469, store into Rx FIFO 0. \r\n"
	       "  2: Send FD standard message with ID: 0x45A and 64 byte data 0 to 63. \r\n"
	       "  3: Send FD standard message with ID: 0x469 and 64 byte data 128 to 191. \r\n"
	       "  4: Set extended filter ID 0: 0x100000A5, store into Rx buffer. \r\n"
	       "  5: Set extended filter ID 1: 0x10000096, store into Rx FIFO 1. \r\n"
	       "  6: Send FD extended message with ID: 0x100000A5 and 64 byte data 0 to 63. \r\n"
	       "  7: Send FD extended message with ID: 0x10000096 and 64 byte data 128 to 191. \r\n"
	       "  a: Send normal standard message with ID: 0x469 and 8 byte data 0 to 7. \r\n"
	       "  h: Display menu \r\n\r\n");
}

static void CAN_0_tx_callback(struct can_async_descriptor *const descr)
{
	(void)descr;
	printf("  CAN Transmission done \r\n");
}

static void CAN_std_tx_callback(struct can_async_descriptor *const descr)
{
	(void)descr;

	/* Enable the FDOE and BRSE in register configuration*/
	hri_can_set_CCCR_INIT_bit(CAN_0.dev.hw);
	while (hri_can_get_CCCR_INIT_bit(CAN_0.dev.hw) == 0)
		;
	hri_can_set_CCCR_CCE_bit(CAN_0.dev.hw);

	hri_can_set_CCCR_FDOE_bit(CAN_0.dev.hw);
	hri_can_set_CCCR_BRSE_bit(CAN_0.dev.hw);

	printf("  CAN Transmission done \r\n");
}

static void CAN_0_rx_callback(struct can_async_descriptor *const descr)
{
	struct can_message msg;
	uint8_t            data[64];
	msg.data = data;
	can_async_read(descr, &msg);

	printf("\n\r CAN Message received . The received data is: \r\n");
	for (uint8_t i = 0; i < msg.len; i++) {
		printf("  %d", msg.data[i]);
	}
	printf("\r\n\r\n");
	return;
}



int32_t _can_async_init_self(struct _can_async_device *const dev, void *const hw, uint32_t bpr)
{
	dev->hw = hw;
	hri_can_set_CCCR_INIT_bit(dev->hw);
	while (hri_can_get_CCCR_INIT_bit(dev->hw) == 0)
	;
	hri_can_set_CCCR_CCE_bit(dev->hw);
	

	if (hw == CAN1) {
		//_can1_dev    = dev;
		//dev->context = (void *)&_can1_context;
		hri_can_set_CCCR_reg(dev->hw, CONF_CAN1_CCCR_REG);
		hri_can_write_MRCFG_reg(dev->hw, CONF_CAN1_MRCFG_REG);
		hri_can_write_NBTP_reg(dev->hw, (CONF_CAN1_BTP_REG & 0xff00ffff ) | CAN_NBTP_NBRP(bpr - 1)    );
		hri_can_write_DBTP_reg(dev->hw, CONF_CAN1_DBTP_REG);
		//hri_can_write_RXF0C_reg(dev->hw, CONF_CAN1_RXF0C_REG | CAN_RXF0C_F0SA((uint32_t)can1_rx_fifo));
		hri_can_write_RXESC_reg(dev->hw, CONF_CAN1_RXESC_REG);
		hri_can_write_TXESC_reg(dev->hw, CONF_CAN1_TXESC_REG);
		//hri_can_write_TXBC_reg(dev->hw, CONF_CAN1_TXBC_REG | CAN_TXBC_TBSA((uint32_t)can1_tx_fifo));
		//hri_can_write_TXEFC_reg(dev->hw, CONF_CAN1_TXEFC_REG | CAN_TXEFC_EFSA((uint32_t)can1_tx_event_fifo));
		hri_can_write_GFC_reg(dev->hw, CONF_CAN1_GFC_REG);
		//hri_can_write_SIDFC_reg(dev->hw, CONF_CAN1_SIDFC_REG | CAN_SIDFC_FLSSA((uint32_t)can1_rx_std_filter));
		//hri_can_write_XIDFC_reg(dev->hw, CONF_CAN1_XIDFC_REG | CAN_XIDFC_FLESA((uint32_t)can1_rx_ext_filter));
		hri_can_write_XIDAM_reg(dev->hw, CONF_CAN1_XIDAM_REG);

		NVIC_DisableIRQ(CAN1_IRQn);
		hri_can_write_ILE_reg(dev->hw, CAN_ILE_EINT0);
	}


	//enable monitor function
	hri_can_set_CCCR_reg(dev->hw, (1 << 5));
	
	
	
	/* Disable CCE to prevent Configuration Change */
	hri_can_clear_CCCR_CCE_bit(dev->hw);
	hri_can_clear_CCCR_INIT_bit(dev->hw);
	while (hri_can_get_CCCR_INIT_bit(dev->hw)) {
	};

	return ERR_NONE;
}


int main(void)
{
	uint8_t key;
	uint32_t ir,nbrp = 1;

	struct can_message msg;
	struct can_filter  filter;

	uint8_t tx_message_0[64];
	uint8_t tx_message_1[64];
	uint8_t tx_message_2[8];

	/* Initializes MCU, drivers and middleware */
	atmel_start_init();
	display_menu();

	/* Initialize the data to be used later */
	for (uint8_t i = 0; i < 64; i++) {
		tx_message_0[i] = i;
	}

	for (uint8_t j = 128; j < 192; j++) {
		tx_message_1[j - 128] = j;
	}

	for (uint8_t k = 0; k < 8; k++) {
		tx_message_2[k] = k;
	}
	
	
		nbrp = 4;

		_can_async_init_self(&((&CAN_0)->dev), CAN1,nbrp);
		filter.id   = 0x469;
		filter.mask = 0;
		can_async_set_filter(&CAN_0, 0, CAN_FMT_STDID, &filter);
		
		
		while(1){
			
			delay_ms(500);
			ir = hri_can_read_IR_reg(CAN1);
			printf("irq %x\r\n",ir);
			
			
			if((ir & CAN_IR_PEA) || (ir & CAN_IR_PED) || (ir & CAN_IR_BO) || (ir & CAN_IR_EW) || (ir & CAN_IR_EP) ){
				nbrp--;
				_can_async_init_self(&((&CAN_0)->dev), CAN1,nbrp);
				printf("wrong baudrate,change nbrp to %d\r\n",nbrp);
				
			}
			else if((ir & CAN_IR_RF0N)){
				printf("find good baudrate, nbrp is %d\r\n",nbrp);
				//caculate the baudrate, input clock is 40Mhz
				printf("the current baudrate is %d\r\n",40000000/nbrp/(CONF_CAN1_BTP_TSEG1+CONF_CAN1_BTP_TSEG2+1));
				while(1);
			}
			
			
			hri_can_write_IR_reg(CAN1, ir);
			
		}
	
//---------------------------------------------------------------	

	while (1) {
		scanf("%c", (char *)&key);

		switch (key) {
		case 'h':
			display_menu();
			break;

		case '0':
			printf("  0: Set standard filter ID 0: 0x45A, store into Rx buffer. \r\n");
			can_async_register_callback(&CAN_0, CAN_ASYNC_RX_CB, (FUNC_PTR)CAN_0_rx_callback);
			filter.id   = 0x45A;
			filter.mask = 0;
			can_async_set_filter(&CAN_0, 0, CAN_FMT_STDID, &filter);
			break;

		case '1':
			printf("  1: Set standard filter ID 1: 0x469, store into Rx FIFO 0. \r\n");
			can_async_register_callback(&CAN_0, CAN_ASYNC_RX_CB, (FUNC_PTR)CAN_0_rx_callback);
			filter.id   = 0x469;
			filter.mask = 0;
			can_async_set_filter(&CAN_0, 1, CAN_FMT_STDID, &filter);
			break;

		case '2':
			printf("  2: Send standard message with ID: 0x45A and 64 byte data 0 to 63. \r\n");
			msg.id   = 0x45A;
			msg.type = CAN_TYPE_DATA;
			msg.data = tx_message_0;
			msg.len  = 64;
			msg.fmt  = CAN_FMT_STDID;

			can_async_register_callback(&CAN_0, CAN_ASYNC_TX_CB, (FUNC_PTR)CAN_0_tx_callback);
			can_async_enable(&CAN_0);
			can_async_write(&CAN_0, &msg);
			break;

		case '3':
			printf("  3: Send standard message with ID: 0x469 and 64 byte data 128 to 191. \r\n");
			msg.id   = 0x469;
			msg.type = CAN_TYPE_DATA;
			msg.data = tx_message_1;
			msg.len  = 64;
			msg.fmt  = CAN_FMT_STDID;

			can_async_register_callback(&CAN_0, CAN_ASYNC_TX_CB, (FUNC_PTR)CAN_0_tx_callback);
			can_async_enable(&CAN_0);
			can_async_write(&CAN_0, &msg);
			break;

		case '4':
			printf("  4: Set extended filter ID 0: 0x100000A5, store into Rx buffer. \r\n");
			can_async_register_callback(&CAN_0, CAN_ASYNC_RX_CB, (FUNC_PTR)CAN_0_rx_callback);
			filter.id   = 0x100000A5;
			filter.mask = 0;
			can_async_set_filter(&CAN_0, 0, CAN_FMT_EXTID, &filter);
			break;

		case '5':
			printf("  5: Set extended filter ID 1: 0x10000096, store into Rx FIFO 1. \r\n");
			can_async_register_callback(&CAN_0, CAN_ASYNC_RX_CB, (FUNC_PTR)CAN_0_rx_callback);
			filter.id   = 0x10000096;
			filter.mask = 0;
			can_async_set_filter(&CAN_0, 1, CAN_FMT_EXTID, &filter);
			break;

		case '6':
			printf("  6: Send extended message with ID: 0x100000A5 and 64 byte data 0 to 63. \r\n");
			msg.id   = 0x100000A5;
			msg.type = CAN_TYPE_DATA;
			msg.data = tx_message_0;
			msg.len  = 64;
			msg.fmt  = CAN_FMT_EXTID;

			can_async_register_callback(&CAN_0, CAN_ASYNC_TX_CB, (FUNC_PTR)CAN_0_tx_callback);
			can_async_enable(&CAN_0);
			can_async_write(&CAN_0, &msg);
			break;

		case '7':
			printf("  7: Send extended message with ID: 0x10000096 and 64 byte data 128 to 191. \r\n");
			msg.id   = 0x10000096;
			msg.type = CAN_TYPE_DATA;
			msg.data = tx_message_1;
			msg.len  = 64;
			msg.fmt  = CAN_FMT_EXTID;

			can_async_register_callback(&CAN_0, CAN_ASYNC_TX_CB, (FUNC_PTR)CAN_0_tx_callback);
			can_async_enable(&CAN_0);
			can_async_write(&CAN_0, &msg);
			break;

		case 'a':
			printf("  a: Send normal standard message with ID: 0x469 and 8 byte data 0 to 7. \r\n");
			msg.id   = 0x469;
			msg.type = CAN_TYPE_DATA;
			msg.data = tx_message_2;
			msg.len  = 8;
			msg.fmt  = CAN_FMT_STDID;

			/* Disable the FDOE and BRSE from register configuration
			 * and enable them again in callback */
			hri_can_set_CCCR_INIT_bit(CAN_0.dev.hw);
			while (hri_can_get_CCCR_INIT_bit(CAN_0.dev.hw) == 0)
				;
			hri_can_set_CCCR_CCE_bit(CAN_0.dev.hw);

			hri_can_clear_CCCR_FDOE_bit(CAN_0.dev.hw);
			hri_can_clear_CCCR_BRSE_bit(CAN_0.dev.hw);

			can_async_register_callback(&CAN_0, CAN_ASYNC_TX_CB, (FUNC_PTR)CAN_std_tx_callback);
			can_async_enable(&CAN_0);
			can_async_write(&CAN_0, &msg);
			break;

		default:
			break;
		}
	}
}
