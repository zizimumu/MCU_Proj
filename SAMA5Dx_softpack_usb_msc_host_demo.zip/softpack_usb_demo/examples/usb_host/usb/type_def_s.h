#ifndef __TYPE_DEF_S_H
#define __TYPE_DEF_S_H



#define  CONFIG_SAMA5D3 1


typedef char __s8;
typedef unsigned char __u8;

typedef  short __s16;
typedef unsigned short __u16;

typedef  int __s32;
typedef unsigned int __u32;

typedef signed char s8;
typedef unsigned char u8;

typedef signed short s16;
typedef unsigned short u16;

typedef signed int s32;
typedef unsigned int u32;


typedef signed long long s64;
typedef unsigned long long u64;

typedef unsigned long		ulong;








/*
typedef unsigned char uint8_t;
typedef unsigned short uint16_t;
typedef unsigned int uint32_t;
*/

typedef unsigned int size_t;

typedef __u16  __le16;
typedef __u16  __be16;
typedef __u32  __le32;
typedef __u32  __be32;

typedef unsigned char bool;


#define __iormb()	asm volatile ("dmb" : : : "memory")
#define __iowmb()	asm volatile ("dmb" : : : "memory")

#define __arch_getb(a)			(*(volatile unsigned char *)(a))
#define __arch_getw(a)			(*(volatile unsigned short *)(a))
#define __arch_getl(a)			(*(volatile unsigned int *)(a))
#define __arch_getq(a)			(*(volatile unsigned long long *)(a))

#define __arch_putb(v,a)		(*(volatile unsigned char *)(a) = (v))
#define __arch_putw(v,a)		(*(volatile unsigned short *)(a) = (v))
#define __arch_putl(v,a)		(*(volatile unsigned int *)(a) = (v))
#define __arch_putq(v,a)		(*(volatile unsigned long long *)(a) = (v))



#if 0
static inline void writeb(volatile void* reg, u8 value)
{
        __iowmb(); __arch_putb(reg,value);
}
#endif

// #define writeb(v,c) { __iowmb(); __arch_putb(v,c);}
// #define writew(v,c) { __iowmb(); __arch_putw(v,c);}
#define writel(v,c)	{ __iowmb(); __arch_putl(v,c);}
// #define writeq(v,c)	{ __iowmb(); __arch_putq(v,c);}

// #define readb(c)	({ u8  __v = __arch_getb(c); __iormb(); __v; })
// #define readw(c)	({ u16 __v = __arch_getw(c); __iormb(); __v; })
#define readl(c)	({ u32 __v = __arch_getl(c); __iormb(); __v; })
// #define readq(c)	({ u64 __v = __arch_getq(c); __iormb(); __v; })

#endif