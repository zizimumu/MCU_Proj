#ifndef ___STR_TO_H__

#define ___STR_TO_H__


unsigned char __tolower(unsigned char c);
unsigned char __toupper(unsigned char c);


#define  tolower(x) __tolower(x)
#define  toupper(x) __toupper(x)


unsigned long simple_strtoul(const char *cp, char **endp,
				unsigned int base);

int strict_strtoul(const char *cp, unsigned int base, unsigned long *res);

long simple_strtol(const char *cp, char **endp, unsigned int base);

#endif
