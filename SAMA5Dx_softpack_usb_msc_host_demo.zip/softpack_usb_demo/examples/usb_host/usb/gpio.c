
#include "gpio_s.h"
#include "device_io.h"
#include <stdio.h>
 
 
 static struct at91_port *at91_pio_get_port(unsigned port)
 {
	 switch (port) {
	 case AT91_PIO_PORTA:
		 return (struct at91_port *)ATMEL_BASE_PIOA;
	 case AT91_PIO_PORTB:
		 return (struct at91_port *)ATMEL_BASE_PIOB;
	 case AT91_PIO_PORTC:
		 return (struct at91_port *)ATMEL_BASE_PIOC;
#if (ATMEL_PIO_PORTS > 3)
	 case AT91_PIO_PORTD:
		 return (struct at91_port *)ATMEL_BASE_PIOD;
#if (ATMEL_PIO_PORTS > 4)
	 case AT91_PIO_PORTE:
		 return (struct at91_port *)ATMEL_BASE_PIOE;
#endif
#endif
	 default:
		 printf("Error: at91_gpio: Fail to get PIO base!\n");
		 return NULL;
	 }
 }


 static void at91_set_port_output(struct at91_port *at91_port, int offset,
				  int value)
 {
	 u32 mask;
 
	 mask = 1 << offset;
	 writel(mask, &at91_port->idr);
	 writel(mask, &at91_port->pudr);
	 
	if(value){
		 writel(mask, &at91_port->sodr);
		}
	else{
		writel(mask, &at91_port->codr);
	}
	 
	 writel(mask, &at91_port->oer);
	 writel(mask, &at91_port->per);
 }


 int at91_set_pio_output(unsigned port, u32 pin, int value)
 {
	 struct at91_port *at91_port = at91_pio_get_port(port);
 
	 if (at91_port && (pin < GPIO_PER_BANK))
		 at91_set_port_output(at91_port, pin, value);
 
	 return 0;
 }


