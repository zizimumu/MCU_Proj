#ifndef __DEVICE_IO_H__
#define __DEVICE_IO_H__


#ifdef CONFIG_SOC_SAMA5D3

	#include "sama5d3.h"
#elif defined CONFIG_SOC_SAMA5D4

	#include "sama5d4.h"
#elif defined CONFIG_SOC_SAMA5D2

	#include "sama5d2.h"
#endif


#endif